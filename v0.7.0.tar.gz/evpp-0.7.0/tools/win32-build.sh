
# Run this script at the directory which holds it.

mkdir -p ../build
cd ../build
cmake ..
