#include <boost/asio.hpp>
#include <boost/thread.hpp>

namespace asio
{
  using namespace boost::asio;
  using boost::system::error_code;
  using boost::thread;
}
