
This directory holds some libraries based on [evpp]:

1. [evmc] a nonblocking async C++ memcached (or membase cluster) client library. This library is currently used in production which sends more than 100 billion requests every day. See [evmc readme](/apps/evmc/readme.md) for more details.
2. [evnsq] a nonblocking async C++ NSQ client library. This library is currently used in production which processes more than 20 billion messages every day. See [evnsq readme](/apps/evnsq/readme.md) for more details.







[evpp]:https://github.com/Qihoo360/evpp
[evmc]:https://github.com/Qihoo360/evpp/tree/master/apps/evmc
[evnsq]:https://github.com/Qihoo360/evpp/tree/master/apps/evnsq